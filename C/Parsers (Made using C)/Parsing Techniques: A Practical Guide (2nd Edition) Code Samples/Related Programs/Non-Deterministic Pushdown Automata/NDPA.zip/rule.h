/* upcall from LL.c and LR.c */
extern void rule(char lhs, const char rhs[]);
