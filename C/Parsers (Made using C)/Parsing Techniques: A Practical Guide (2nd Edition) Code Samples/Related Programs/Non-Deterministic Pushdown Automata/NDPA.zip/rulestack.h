extern void push_rule(char lhs, const char *rhs);
extern void pop_rule(void);
extern void print_derivation(void);
