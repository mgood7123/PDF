extern const char input[];
extern char start;
extern void grammar(void);
