/* see grammar.h  for a description of the data structures */

extern FILE *ifile;
extern const char *iname;
extern int line_number;

extern int read_grammar(void);
extern int read_fsa(void);
