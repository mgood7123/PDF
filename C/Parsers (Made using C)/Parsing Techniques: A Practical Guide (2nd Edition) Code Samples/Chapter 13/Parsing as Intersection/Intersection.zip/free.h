extern void free_symbol(struct symbol *s);
extern void free_tree(struct symbol *s);
