extern const char *progname;
extern void error_and_exit(const char *msg);
