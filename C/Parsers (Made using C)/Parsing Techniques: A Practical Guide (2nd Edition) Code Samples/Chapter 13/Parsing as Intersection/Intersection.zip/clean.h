extern void clean(void);
