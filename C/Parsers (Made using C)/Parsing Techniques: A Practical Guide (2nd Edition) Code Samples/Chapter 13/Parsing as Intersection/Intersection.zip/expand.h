extern void intersect(void);
