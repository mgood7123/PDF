extern int r_flag;
extern int v_flag;
