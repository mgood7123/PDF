extern void error(const char *msg);
