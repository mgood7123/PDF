extern void AddProductionToParse(int m);

extern void PrintProduction(int m);
extern void PrintParse(void);
extern void PrintParseTree(void);

