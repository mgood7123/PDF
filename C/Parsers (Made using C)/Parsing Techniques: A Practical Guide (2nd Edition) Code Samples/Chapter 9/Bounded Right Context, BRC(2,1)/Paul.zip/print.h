extern void print_grammar(void);
extern void print_tables(void);
extern void print_RTTsize(void);
extern void print_RTT(void);
extern void print_status(const char *X, int r, int s);
