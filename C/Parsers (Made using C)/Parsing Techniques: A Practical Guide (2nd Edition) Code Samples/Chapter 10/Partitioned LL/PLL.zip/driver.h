extern int dot;
extern void token(int ch);

extern void print(const char *s);
extern int error(const char *adm);
