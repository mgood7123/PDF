extern char S(void);
