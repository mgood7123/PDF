extern void
Compute_VkInf(const struct rule *grammar, const Symbol *XY, ItemSet VkInf);
