extern void test_sentential_form(const Symbol *s_form);
extern void parse_sentence(const Symbol *s_form);
