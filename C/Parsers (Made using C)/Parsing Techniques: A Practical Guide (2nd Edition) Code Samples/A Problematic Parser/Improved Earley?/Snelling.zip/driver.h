extern char X[MAX_n+1];			/* the input */
extern int n;				/* its length */
