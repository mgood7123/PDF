extern void print_grammar(void);
extern void print_input(void);
extern void pp(int p_tree);
extern void print_alt(int rl, int strt);
