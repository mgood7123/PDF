#include	"driver.h"

char input[] = "a";

char start = 'E';

void
grammar(void) {
	rule('E', "a");
}

