#define	IOSIZE	10000

extern int STGOAL;
extern int STCOMP;
extern int stab_pos;

extern int DIAGRAM(int i, int GOAL, int *PARAM);
extern void rule(int subj, char *comp);
extern void grammar(void);
