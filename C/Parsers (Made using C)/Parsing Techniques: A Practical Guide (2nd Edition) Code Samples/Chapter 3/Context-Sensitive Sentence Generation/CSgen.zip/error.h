/*	This file is part of the CS sentence generator CSgen
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
	$Id: error.h,v 1.1 2016-09-13 19:20:36 Gebruiker Exp $
*/

extern void error(const char *where, const char *what);
